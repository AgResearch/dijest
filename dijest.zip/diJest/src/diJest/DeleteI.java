package diJest;
/**
 * Interface that delete Files
 * @author Clément DELESTRE
 * @version 1.0
 *
 */
public interface DeleteI {
	/**
	 * Method to use to delete files
	 */
	public void deleteFiles();
}
